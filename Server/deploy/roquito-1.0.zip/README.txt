README BLANK

##Resources
https://wimdeblauwe.wordpress.com/2014/11/04/spring-boot-application-with-exploded-directory-structure/